This is the Parallel and Sequential Mining Suite (ParSeMiS), built 2008-12-01.

To run/compile parts of ParSeMiS different extern libraries are required:

- ant     (http://antlr.org/download.html) for parsing dot-files 
   known running version: 2.7.6
- prefuse (http://prefuse.org/download/)   for gui
   known running version: release 2007.10.21

Please add the corresponding .jar files to the lib directory.

Run "java -jar parsemis-2008-12-01.jar" for usage and see index.html and further 
from the javadoc directory for documentation.
